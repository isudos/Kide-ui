Template.SaveDialog.rendered = function() {
    //$(function () { $('#fileTreeContainer').jstree(); });
    //Meteor.subscribe("fileSystem");
    var fileSystemRoot = FileTrees.findOne();
    console.log(fileSystemRoot);
    if(fileSystemRoot.text != '/'){
        AntiModals.alert("Error initializing file system. File system seems to be corrupt.");
    } else {
        $(function() {$('#saveFileTreeContainer').jstree({ 'core' : {
          'data' : fileSystemRoot
      } });});  //jstree({'core' : {'data': fileSystemRoot }});
    }

    this.autorun(function() {
        var fsRoot = FileTrees.findOne();
        console.log("refreshed");
        $('#saveFileTreeContainer').jstree(true).settings.core.data = fsRoot;
        $('#saveFileTreeContainer').jstree(true).refresh();
        $('#saveFileTreeContainer').jstree(true).redraw(true);
    });
};

Template.SaveDialog.events({
	"click [id='savefilebutton']": function(event, template) {
		var filePath = $("#saveFilePath").val();
		console.log("Saving file: " + filePath);
		var cm = $('#EditorPageArea').data('CodeMirrorInstance');
		var codeText = cm.getValue();
		Meteor.call('saveAs', filePath, codeText);
	}
});