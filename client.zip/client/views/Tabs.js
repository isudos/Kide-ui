Template.Tabs.helpers({
  currentFile: Session.get('currentFile')
});