Template.editor.rendered = function() {
    var editor = CodeMirror.fromTextArea(this.find("#EditorPageArea"), {
        lineNumbers: true,
        mode: "javascript" // set any of supported language modes here
    });


    $('#EditorPageArea').data('CodeMirrorInstance', editor);
    console.log(editor);
    if (Session.get('currentFile') != '' && Session.get('currentFile') != null && Session.get('currentFile') != undefined) {
    	Meteor.call('open', Session.get('currentFile'),  function (error, result) {
          if (error) {
            AntiModals.alert("File is unaccessable.");
          } else {
                if (result == null){
                    AntiModals.alert("File doesn't exist.");
                } else {
                    editor.setValue(result);
                }
          }
        });
        
    } else {
        Session.set('currentFile', 'newfile.txt');
        editor.setValue('');
    }
};