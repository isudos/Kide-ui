Template.OpenDialog.rendered = function() {
    //$(function () { $('#fileTreeContainer').jstree(); });
    //Meteor.subscribe("fileSystem");
    var fileSystemRoot = FileTrees.findOne();
    console.log(fileSystemRoot);
    if(fileSystemRoot.text != '/'){
        AntiModals.alert("Error initializing file system. File system seems to be corrupt.");
    } else {
        $(function() {$('#openFileTreeContainer').jstree({ 'core' : {
         'data' : fileSystemRoot
      } });});  //jstree({'core' : {'data': fileSystemRoot }});
    }

    this.autorun(function() {
        var fsRoot = FileTrees.findOne();
        console.log("refreshed");
        $('#openFileTreeContainer').jstree(true).settings.core.data = fsRoot;
        $('#openFileTreeContainer').jstree(true).refresh();
        $('#openFileTreeContainer').jstree(true).redraw(true);
    });

};

Template.OpenDialog.events({
	"click [id='openfilebutton']": function(event, template) {
		var filePath = $("#openFilePath").val();
		console.log("Open file: " + filePath);
        //var codeText = null;
		Meteor.call('open', filePath,  function (error, result) {
          if (error) {
            AntiModals.alert("File is unaccessable.");
          } else {
                if (result == null){
                    AntiModals.alert("File doesn't exist.");
                } else {
                    var cm = $('#EditorPageArea').data('CodeMirrorInstance');
                    console.log(result);
                    cm.setValue(result);
                }
          }
        });

		
	}
});