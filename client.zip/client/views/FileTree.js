Template.FileTree.rendered = function() {
    //$(function () { $('#fileTreeContainer').jstree(); });
    //Meteor.subscribe("fileSystem");
    var fileSystemRoot = FileTrees.findOne();
    console.log(fileSystemRoot);
    if(fileSystemRoot.text != '/'){
        AntiModals.alert("Error initializing file system. File system seems to be corrupt.");
    } else {
        $(function() {$('#fileTreeContainer').jstree({ 'core' : {
          'data' : fileSystemRoot
      } });});  //jstree({'core' : {'data': fileSystemRoot }});
    }

    this.autorun(function() {
        var fsRoot = FileTrees.findOne();
        console.log("refreshed");
        $('#fileTreeContainer').jstree(true).settings.core.data = fsRoot;
        $('#fileTreeContainer').jstree(true).refresh();
        $('#fileTreeContainer').jstree(true).redraw(true);
    });
};